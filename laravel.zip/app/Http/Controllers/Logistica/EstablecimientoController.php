<?php

namespace App\Http\Controllers\Logistica;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Logistica\Establecimiento;

class EstablecimientoController extends Controller
{
    //
}
